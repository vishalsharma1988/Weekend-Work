<?php

/**
 * Fired during plugin activation
 *
 * @link       https://wordpress.org/
 * @since      1.0.0
 *
 * @package    Export_Items
 * @subpackage Export_Items/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Export_Items
 * @subpackage Export_Items/includes
 * @author     vishal sharma <vishal@cmsminds.com>
 */
class Export_Items_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
