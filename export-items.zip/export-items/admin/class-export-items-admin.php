<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wordpress.org/
 * @since      1.0.0
 *
 * @package    Export_Items
 * @subpackage Export_Items/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Export_Items
 * @subpackage Export_Items/admin
 * @author     vishal sharma <vishal@cmsminds.com>
 */
class Export_Items_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	//	add_action( 'admin_init', [ $this, 'add_export_button' ] );
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Export_Items_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Export_Items_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/export-items-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Export_Items_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Export_Items_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/export-items-admin.js', array( 'jquery' ), $this->version, false );

	}

 
public function add_export_button( $right_button ) {
    global $post_type;
  
    if ( 'post' === $post_type && 'top' === $right_button ) {
        ?>
        <input id="export-button" type="submit" name="export_items" class="button button-primary" value="<?php _e('Export Items'); ?>" />
        <?php
    }
}

public function func_export_itesms() {


    if(isset($_GET['export_items'])) {
        $arg = array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => -1,
            );
 
        global $post;
        $all_post = get_posts($arg);
        if ($all_post) {
 
            header('Content-type: text/csv');
            header('Content-Disposition: attachment; filename="export_items.csv"');
            header('Pragma: no-cache');
            header('Expires: 0');
 
            $file = fopen('php://output', 'w');
 
            fputcsv($file, array('Post Title', 'URL', 'Categories', 'Tags', 'Content'));
  
            foreach ($all_post as $post) {
                setup_postdata($post);
                  
                $categories = get_the_category();
                $cats = array();
                if (!empty($categories)) {
                    foreach ( $categories as $category ) {
                        $cats[] = $category->name;
                    }
                }
  
                $post_tags = get_the_tags();
                $tags = array();
                if (!empty($post_tags)) {
                    foreach ($post_tags as $tag) {
                        $tags[] = $tag->name;
                    }
                }
  
                fputcsv($file, array(get_the_title(), get_the_permalink(), implode(",", $cats), implode(",", $tags), get_the_content()));
            }
  
            exit();
        }
    }
}

}
